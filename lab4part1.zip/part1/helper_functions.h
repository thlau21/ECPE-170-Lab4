#ifndef HELPER_FUNCTIONS_H
#define HELPER_FUNCTIONS_H

void initArray(int *array_start, int array_size);
void bubbleSort(int *array_start, int array_size);
bool verifySort(int *array_start, int array_size);

#endif // HELPER_FUNCTIONS_H

